import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class Main {

	public static void main(String[] args) {
		MinecraftBlocks test = new MinecraftBlocks();
/*
		try {
			WallFacade.importImage("blank");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// WallFacade.setAverageColor();
		WallFacade.createAndFillColorTileArray();
		WallFacade.paintArray();
		// WallFacade.exportImage();
		WallFacade.createAndFillBlockArray();
		WallFacade.blockArrayDebug();
		WallFacade.paintBlockTiles();
*/
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JFrame frame = new JFrame("BuildingToMinecraft");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		frame.setSize((int) screenSize.getWidth(), (int) screenSize.getWidth());
		frame.setVisible(true);

		JTabbedPane tabbedPane = new JTabbedPane();
		tabbedPane.addTab("MainMenu", new MainMenu(tabbedPane));
		frame.getContentPane().add(tabbedPane);

	}

}
