import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class BuildingData {
	final int WALLCOUNT = 4;

	private WallFacade[] wallFacadeArray;
	private String buildingName;

	// The number the user inputs as the meter scale
	private int meterScale;
	// the pixel distance from the two clicks
	private int meterPixels;
	// the meterpixesl/meterscale
	private double mpRatio;

	private ArrayList<int[]> cords;
	private int[] wallSizes;
	private int[] wallSizeInMeters;
	private int wallHeight;

	private boolean ready;
	private int wallPixelHeight;
	// private int[] wallSizes;

	// wall facade data stuff
	// private int[][] meterStickCords;

	public BuildingData() {
		cords = new ArrayList<int[]>();
		wallFacadeArray = new WallFacade[WALLCOUNT];
		ready = false;
		// meterStickCords= new int[2][2];
	}

	public void setMeterPixels() {
		meterPixels = Math.abs(cords.get(0)[0] - cords.get(1)[0]);
		System.out.println(cords.get(0)[0] + " and " + cords.get(1)[0]);
		System.out.println("Set meters was ran: " + meterPixels);
		setMPRatio();
	}

	private void setMPRatio() {
		mpRatio = meterPixels / meterScale;
	}

	public int getMeterScale() {
		return meterScale;
	}

	public void setWallSizes() {
		wallSizes = new int[WALLCOUNT];
		wallSizeInMeters = new int[2];
		// TODO Make this not hard coded
		if (cords.size() == 6) {
			wallSizes[0] = (int) getDistance(cords.get(2)[0], cords.get(2)[1], cords.get(3)[0], cords.get(3)[1]);
			wallSizes[1] = (int) getDistance(cords.get(3)[0], cords.get(3)[1], cords.get(4)[0], cords.get(4)[1]);
			wallSizes[2] = (int) getDistance(cords.get(4)[0], cords.get(4)[1], cords.get(5)[0], cords.get(5)[1]);
			wallSizes[3] = (int) getDistance(cords.get(5)[0], cords.get(5)[1], cords.get(2)[0], cords.get(2)[1]);

			wallSizeInMeters[0] = (int) (((wallSizes[0] + wallSizes[2]) / 2) / mpRatio);
			wallSizeInMeters[1] = (int) (((wallSizes[1] + wallSizes[3]) / 2) / mpRatio);
		} else {
			System.out.println("Not exatcly 6 points in cords array: " + cords.size());
		}

	}

	public int getWallSize(int i) {

		return wallSizes[i];
	}

	public int getWallSizeInMeters(int i) {
		return wallSizeInMeters[i];
	}

	private double getDistance(int x1, int y1, int x2, int y2) {
		double distance = Math.hypot(x1 - x2, y1 - y2);
		return distance;
	}

	public int getMeterPixels() {
		return meterPixels;
	}

	public void setMeterScale(int m) {
		meterScale = m;
		System.out.println("Get was succesful number is: " + meterScale);
	}

	public int[] getCord(int i) {
		return cords.get(i);
	}

	public void addCord(int[] cord) {
		cords.add(cord);
	}

	// TODO Wall facade nonsense
	public void setWallFacade(int wallNumber, BufferedImage image) {
		// int meterStick = Math.abs(meterStickCords[0][1] - meterStickCords[1][1]) * 2;
		// System.out.println("Debug: meterstick size in pixels: " + meterStick);
		if (wallNumber == 0 || wallNumber == 2) {
			wallFacadeArray[wallNumber] = new WallFacade(wallSizeInMeters[0], wallHeight, image);

		} else {
			wallFacadeArray[wallNumber] = new WallFacade(wallSizeInMeters[1], wallHeight, image);
		}

		// wallFacadeArray[wallNumber].importImage(image);
		wallFacadeArray[wallNumber].execute();

	}

	public void setWallHeight(int[][] meterStickCords, BufferedImage image) {
		int meterStick = Math.abs(meterStickCords[0][1] - meterStickCords[1][1]) * 2;
		wallHeight = (int) image.getHeight() / meterStick;
		System.out.println("Debug: Wallheight = " + wallHeight);
		wallPixelHeight=image.getHeight();
		ready = true;

	}

	public WallFacade getWallFacade(int wallNumber) {
		return wallFacadeArray[wallNumber];
	}

	// TODO fix
	public void createNBT() {
		Boolean status = true;
		for (int i = 0; i < wallFacadeArray.length; i++) {
			if (wallFacadeArray[i] == null) {
				status = false;
			}
		}
		if (status) {
			NBTWriter writer = new NBTWriter(wallFacadeArray[0].getBlockTileArray(),
					wallFacadeArray[1].getBlockTileArray(), wallFacadeArray[2].getBlockTileArray(),
					wallFacadeArray[3].getBlockTileArray(), buildingName);
			writer.generateNBT();
		}
	}

	public boolean getReadyStatus() {
		return ready;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public int getWallPixelHeight() {
		return wallPixelHeight;
	}

}
