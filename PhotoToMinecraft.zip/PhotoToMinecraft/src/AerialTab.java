import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

public class AerialTab extends JPanel {

	private JTabbedPane topMenu;

	private BuildingData data;

	// this is testing
	private JLabel meterScale;
	private JLabel ratio;

	private JLabel instructions;
//not sure if these are needed?
	private JPanel westStagePanel;
	private JPanel eastStagePanel;

	private AerialCenterPanel center;

	// Added 3/13/2021
	private JPanel north;
	private JButton topButton;
	private JTextField name;
	
//	private int state;
	// end testing

	public AerialTab(JTabbedPane topMenu) {

		data = new BuildingData();

		this.topMenu = topMenu;

		setLayout(new BorderLayout());

		 name = new JTextField(16);

		north = new JPanel();
		north.setLayout(new GridLayout(1, 2));

		topButton = new JButton("Name your building");

		north.add(name);
		north.add(topButton);

//TODO make the FileViewActionListner communicate more directly with aerialCenterPanel
		topButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent evt) {
				System.out.println("Click ran");
				data.setBuildingName(name.getText());
				nameEntered();

			}
		});
		instructions = new JLabel("ToolTip: Name your building and click begin.");

		this.add(instructions, BorderLayout.SOUTH);

		this.add(north, BorderLayout.NORTH);

		// this.addMouseListener(this);

	}

	// TODO this is new 3/13/2021
	public void nameEntered() {
		north.remove(topButton);
		north.remove(name);
		topButton = new JButton("Import an Aerial image:");
		// this.add(importButton, BorderLayout.NORTH);
		topButton.addActionListener(new FileViewActionListner(this));
		north.add(topButton);
		instructions = new JLabel("ToolTip: Import an aerial photo of a building to begin.");

	}

	private void setWestStage(JPanel stage) {
		if (westStagePanel != null) {
			this.remove(westStagePanel);
		}
		westStagePanel = stage;
		this.add(westStagePanel, BorderLayout.WEST);
		this.validate();
		this.repaint();
	}

	// after adding a picture this should fire
	public void westStage1() {
		// making the intial west buttons etc
		JPanel westStage1 = new JPanel();
		westStage1.setLayout(new GridLayout(10, 1));

		JLabel meterDisc = new JLabel("Please type in the meter scale:");
		westStage1.add(meterDisc);

		JTextField meter = new JTextField(16);
		westStage1.add(meter);

		JButton startB = new JButton("Start");
		westStage1.add(startB);

		startB.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent evt) {
				data.setMeterScale(Integer.parseInt(meter.getText()));
				meterScale.setText("Meter Scale: " + data.getMeterScale());
				center.setState(1);
				westStage2();
				// data.setMeterPixels(cord1, cord2);
				// ratio.setText(data.getMeterScale() + " Meters is " + data.getMeterPixels() +
				// " Pixels");

			}
		});

		setWestStage(westStage1);
	}

	public void westStage2() {

		JPanel westStage2 = new JPanel();
		westStage2.setLayout(new GridLayout(10, 1));

		JLabel meterDisc = new JLabel("TESTING");
		westStage2.add(meterDisc);

		JTextField meter = new JTextField(16);
		westStage2.add(meter);

		setWestStage(westStage2);
	}

	public void eastStage() {

		// System.out.println("EastStage was ran " +data.getMeterScale());

		JPanel eastStage = new JPanel();
		eastStage.setLayout(new GridLayout(10, 1));

		meterScale = new JLabel("Meter Scale: " + data.getMeterScale());
		ratio = new JLabel(data.getMeterScale() + " Meters is " + data.getMeterPixels() + " Pixels");
		eastStage.add(meterScale);
		eastStage.add(ratio);
		this.add(eastStage, BorderLayout.EAST);

	}

	public void addPicture(BufferedImage pic) {

		center = new AerialCenterPanel(this, pic, data, topMenu);

		this.add(center, BorderLayout.CENTER);
		revalidate();
		westStage1();
		eastStage();

		instructions.setText("ToolTip: Now enter in the meter size and click start");
		repaint();
	}

	public void upDateEastStage() {
		ratio.setText(data.getMeterScale() + " Meters is " + data.getMeterPixels() + " Pixels");
		repaint();
	}

}