import java.awt.Color;
import java.awt.image.BufferedImage;

public class Block {
	private BufferedImage blockPNG;
	
	private String blockName;
	
	private Color blockColor;

	public BufferedImage getBlockPNG() {
		return blockPNG;
	}

	public void setBlockPNG(BufferedImage blockPNG) {
		this.blockPNG = blockPNG;
	}

	public String getBlockName() {
		return blockName;
	}

	public void setBlockName(String blockName) {
		this.blockName = blockName;
	}

	public Color getBlockColor() {
		return blockColor;
	}

	public void setBlockColor(Color blockColor) {
		this.blockColor = blockColor;
	}

	public Block(BufferedImage blockPNG, String blockName, Color blockColor) {

		this.blockPNG = blockPNG;
		this.blockName = blockName;
		this.blockColor = blockColor;
	}
	
}
