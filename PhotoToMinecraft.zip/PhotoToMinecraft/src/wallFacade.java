import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class WallFacade {

	// scale meaning for every 1 meter there are SCALE blocks
	// such that a building 30 meters long with have 150 blocks
	// You then must find what divides that to equal
	private int scale = 5;

	private int wallHeightMeasurement;
	private int wallWidthMeasurement;

//	private int measurement = 5;
	private BufferedImage img;

	// private int meterStickMeasurementInPixels;

	private BufferedImage MCWallImage;
	// these are temporary variables to test my code they will either be replaced
	// or simply deleted
//	private static BufferedImage product;
	private int imageW;
	private int imageH;

	private Color[][] colorTileArray;
	private Block[][] blockTileArray;

	public WallFacade(int wallWidth, int wallHeight,BufferedImage img) {
		importImage(img);
		wallWidthMeasurement=divisionSolver(img.getWidth(),wallWidth*scale);
		wallHeightMeasurement=divisionSolver(img.getHeight(),wallHeight*scale);
		System.out.println("Wall height and width in meters" + wallHeight+", "+wallWidth);
		
		System.out.println(img.getHeight()/wallHeightMeasurement+" supposed to be = "+ (5*wallHeight));
		
	}
	public static int divisionSolver(int pixels, int meters) {
		int difference = Integer.MAX_VALUE;
		int xValue=0;
		for(int i=1;i<pixels;i++) {
			int temp = pixels/i;
			int tempDifference = Math.abs(meters-temp);
			if(tempDifference <difference) {
				difference=tempDifference;
				xValue=i;
			}
			
		}
		
		return xValue;
	}

	public void execute() {
		createAndFillColorTileArray();
		paintArray();
		createAndFillBlockArray();
		//blockArrayDebug();
		paintBlockTiles();
	}

	public BufferedImage getImageProduct() {
		return MCWallImage;
	}

	// added 2/15/2021 while making this file not static
	private void importImage(BufferedImage img) {
		this.img = img;
		imageW = img.getWidth();
		imageH = img.getHeight();

		System.out.println("Image Width: " + imageW + " Image Height: " + imageH);
		System.out.println();
	}

	public void importImage(String filename) throws IOException {
		img = ImageIO.read(new File("building.bmp"));
		imageW = img.getWidth();
		imageH = img.getHeight();

		System.out.println("Image Width: " + imageW + " Image Height: " + imageH);
		System.out.println();
	}

	public void createAndFillColorTileArray() {
		colorTileArray = new Color[(int) imageH / wallHeightMeasurement][(int) imageW / wallWidthMeasurement];

		System.out.println(colorTileArray.length);
		System.out.println(colorTileArray[0].length);

		for (int i = 0; i < colorTileArray.length; i++) {
			for (int j = 0; j < colorTileArray[0].length; j++) {
				colorTileArray[i][j] = getAverageColor(j, i);
			}

		}

	}

	public Color getAverageColor(int xStart, int yStart) {
		// BufferedImage bi, int x0, int y0, int w, int h
		xStart *= wallWidthMeasurement;
		yStart *= wallHeightMeasurement;
		int xFinish = xStart + wallWidthMeasurement;
		int yFinish = yStart + wallHeightMeasurement;
		long sumr = 0, sumg = 0, sumb = 0;
		for (int x = xStart; x < xFinish; x++) {
			for (int y = yStart; y < yFinish; y++) {
				Color pixel = new Color(img.getRGB(x, y));
				sumr += pixel.getRed();
				sumg += pixel.getGreen();
				sumb += pixel.getBlue();
			}
		}
		int num = wallWidthMeasurement * wallHeightMeasurement;

		Color Average = new Color((int) (sumr / num), (int) (sumg / num), (int) (sumb / num));
		// System.out.println(Average);
		return Average;
	}

//
	/*
	 * public static void setAverageColor() { product = new BufferedImage(imageW,
	 * imageH, BufferedImage.TYPE_INT_RGB); Color average = getAverageColor();
	 * System.out.println(average); for (int x = 0; x < imageW; x++) { for (int y =
	 * 0; y < imageH; y++) { product.setRGB(x, y, average.getRGB()); } } }
	 */

	public void paintArray() {
		BufferedImage product = new BufferedImage(imageW, imageH, BufferedImage.TYPE_INT_RGB);
		for (int x = 0; x < colorTileArray[0].length; x++) {
			for (int y = 0; y < colorTileArray.length; y++) {
				int testX = x * wallWidthMeasurement;
				int testY = y * wallHeightMeasurement;
				for (int i = testX; i < testX + wallWidthMeasurement; i++) {
					for (int j = testY; j < testY + wallHeightMeasurement; j++) {
						product.setRGB(i, j, colorTileArray[y][x].getRGB());
					}
				}

			}
		}
		exportImage("colorTileArray.png", product);

	}

	private void exportImage(String fileName, BufferedImage bi) {
		File f = new File(fileName);
		try {
			ImageIO.write(bi, "PNG", f);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void paintBlockTiles() {
		BufferedImage product = new BufferedImage(blockTileArray[0].length * 16, blockTileArray.length * 16,
				BufferedImage.TYPE_INT_RGB);
		Graphics2D g2 = product.createGraphics();

		for (int i = 0; i < blockTileArray.length; i++) {
			for (int j = 0; j < blockTileArray[0].length; j++) {
				g2.drawImage(blockTileArray[i][j].getBlockPNG(), null, j * 16, i * 16);
			}

		}
		g2.dispose();
		MCWallImage = product;
		exportImage("blockTileArray.png", product);
	}

	public void createAndFillBlockArray() {
		blockTileArray = new Block[colorTileArray.length][colorTileArray[0].length];

		for (int i = 0; i < blockTileArray.length; i++) {
			for (int j = 0; j < blockTileArray[0].length; j++) {
				double distance = Integer.MAX_VALUE;
				for (int blockNum = 0; blockNum < MinecraftBlocks.getLoadedBlocks().length; blockNum++) {
					if (distance > compareColors(colorTileArray[i][j],
							MinecraftBlocks.getLoadedBlocks()[blockNum].getBlockColor())) {
						distance = compareColors(colorTileArray[i][j],
								MinecraftBlocks.getLoadedBlocks()[blockNum].getBlockColor());
						blockTileArray[i][j] = MinecraftBlocks.getLoadedBlocks()[blockNum];
					}
				}

			}
		}
	}

	// returns the max average distance between 2 colors
	private double compareColors(Color a, Color b) {

		double distance = (a.getRed() - b.getRed()) * (a.getRed() - b.getRed())
				+ (a.getGreen() - b.getGreen()) * (a.getGreen() - b.getGreen())
				+ (a.getBlue() - b.getBlue()) * (a.getBlue() - b.getBlue());

		return distance;
	}

	public void blockArrayDebug() {
		for (int i = 0; i < blockTileArray.length; i++) {
			for (int j = 0; j < blockTileArray[0].length; j++) {
				System.out.print("[" + blockTileArray[i][j].getBlockName() + "]");
			}
			System.out.println();
		}

	}

	public Block[][] getBlockTileArray() {
		return blockTileArray;
	}
	public int getImageW() {
		return imageW;
	}
	public int getImageH() {
		return imageH;
	}
	

}
