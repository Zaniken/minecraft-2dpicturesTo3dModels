import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.jnbt.ByteArrayTag;
import org.jnbt.CompoundTag;
import org.jnbt.IntTag;
import org.jnbt.NBTOutputStream;
import org.jnbt.ShortTag;
import org.jnbt.Tag;

public class NBTWriter {

	private ArrayList<Block[][]> walls;
	private String[][][] structureString;
	private ArrayList<String> blocksUsed;

	private int height;
	private int width;
	private int length;

	private String fileName;
	public NBTWriter(Block[][] wall1, Block[][] wall2, Block[][] wall3, Block[][] wall4,String fileName) {
		this.fileName=fileName;
		
		walls = new ArrayList<Block[][]>();
		blocksUsed = new ArrayList<String>();
		walls.add(wall1);
		walls.add(wall2);
		walls.add(wall3);
		walls.add(wall4);

		height = wall1.length;
		width = wall1[0].length;
		length = wall2[0].length;

		System.out.println("Wall1[0].length " + wall1[0].length);
		System.out.println("Wall1.length " + wall1.length);

		System.out.println("Wall2[0].length " + wall2[0].length);
		System.out.println("Wall2.length " + wall2.length);

		System.out.println("Wall3[0].length " + wall3[0].length);
		System.out.println("Wall3.length " + wall3.length);

		System.out.println("Wall4[0].length " + wall4[0].length);
		System.out.println("Wall4.length " + wall4.length);

	}

	public void generateNBT() {

		// int TESTSIZE = 10;

		IntTag dataVersion = new IntTag("DataVersion", 2584);
		ShortTag height = new ShortTag("Height", (short) this.height);
		ShortTag width = new ShortTag("Width", (short) this.width);
		ShortTag Length = new ShortTag("Length", (short) this.length);
		IntTag version = new IntTag("Version", 2);

		// TODO call function that adds all palletes
		// *******************************************************

		HashMap<String, Tag> paletteHash = new HashMap<String, Tag>();

		// initilizes block string array
		setBlockStringArray();
		configurePalette(paletteHash);
		CompoundTag paletteTag = new CompoundTag("Palette", paletteHash);
		// *******************************************************

		HashMap<String, Tag> mainHash = new HashMap<String, Tag>();

		walls();
		byte[] testByteArray = ArrayToByteStream();

		ByteArrayTag blockArrayTag = new ByteArrayTag("BlockData", testByteArray);

		mainHash.put("Palette", paletteTag);
		mainHash.put("DataVersion", dataVersion);
		mainHash.put("Height", height);
		mainHash.put("Width", width);
		mainHash.put("Length", Length);
		mainHash.put("Version", version);
		mainHash.put("BlockData", blockArrayTag);
		CompoundTag mainTag = new CompoundTag("Schematic", mainHash);

		FileOutputStream fos = null;
		File file;
		try {
			// Specify the file path here
			file = new File(fileName+".schem");
			fos = new FileOutputStream(file);

			NBTOutputStream nbtOut = new NBTOutputStream(fos);

			nbtOut.writeTag(mainTag);

			nbtOut.close();

			// fos.write();
			fos.flush();
			System.out.println("File Written Successfully");
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			try {
				if (fos != null) {
					fos.close();
				}
			} catch (IOException ioe) {
				System.out.println("Error in closing the Stream");
			}
		}

	}

	public void setBlockStringArray() {
		blocksUsed.add("air");
		for (Block[][] wall : walls) {
			for (int i = 0; i < wall.length; i++) {
				for (int j = 0; j < wall[0].length; j++) {
					String temp = wall[i][j].getBlockName();
					temp = temp.replace(".png", "");
					if (!blocksUsed.contains(temp)) {
						blocksUsed.add(temp);
					}
				}
			}
		}

	}

	public void configurePalette(HashMap<String, Tag> paletteHash) {
		IntTag[] blockIntTags = new IntTag[blocksUsed.size()];

		for (int i = 0; i < blocksUsed.size(); i++) {
			blockIntTags[i] = new IntTag("minecraft:" + blocksUsed.get(i), i);
			paletteHash.put("minecraft:" + blocksUsed.get(i), blockIntTags[i]);
		}
	}

	public void walls() {

		String[][][] building = new String[width][height][length];

		// wall 1 Building[x][y][z]
		// [x][y][0]

		int x;
		int y = height - 1;
		for (int i = 0; i < walls.get(0).length; i++) {
			x = 0;
			for (int j = 0; j < walls.get(0)[0].length; j++) {

				String temp = walls.get(0)[i][j].getBlockName();
				temp = temp.replace(".png", "");
				building[x][y][0] = temp;
				x++;
			}

			y--;
		}
		// wall 2
		// [length-1][y][z] z goes down as it goes
		y = height - 1;
		int z;
		for (int i = 0; i < walls.get(1).length; i++) {
			z = length - 1;
			for (int j = 0; j < walls.get(1)[0].length; j++) {

				String temp = walls.get(1)[i][j].getBlockName();
				temp = temp.replace(".png", "");
				building[width - 1][y][z] = temp;
				z--;
			}
			y--;
		}
		// wall 3
		y = height - 1;
		for (int i = 0; i < walls.get(2).length; i++) {
			x = width - 1;
			for (int j = 0; j < walls.get(2)[0].length; j++) {

				String temp = walls.get(2)[i][j].getBlockName();
				temp = temp.replace(".png", "");

				building[x][y][length - 1] = temp;
				x--;
			}
			y--;
		}
		// wall 4
		y = height - 1;
		for (int i = 0; i < walls.get(3).length; i++) {
			z = 0;
			for (int j = 0; j < walls.get(3)[0].length; j++) {

				String temp = walls.get(3)[i][j].getBlockName();
				temp = temp.replace(".png", "");

				building[0][y][z] = temp;
				z++;
			}
			y--;
		}
		// null area

		structureString = building;
	}

	public byte[] ArrayToByteStream() {

		byte[] blockarray = new byte[width * height * length];
		for (int x = 0; x < width; x++) {
			for (int y = 0; y < height; y++) {
				for (int z = 0; z < length; z++) {

					if (structureString[x][y][z] != null) {

						blockarray[x + z * width + y * width * length] = (byte) blocksUsed
								.indexOf(structureString[x][y][z]);

					} else {
						blockarray[x + z * width + y * width * length] = (byte) blocksUsed.indexOf("air");
					}
				}
			}
		}
		return blockarray;

	}

}
