import java.awt.Image;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.PointerInfo;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.WritableRaster;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class WallCenterPanel extends JPanel implements MouseListener {

	private int state;

	private BuildingData data;
	private JLabel picture;
	private BufferedImage pic;
	private final int scale = 4;
	private WallTab tab;
	private BufferedImage picOriginal;
	private int[][] meterStickCord;

	public WallCenterPanel(BuildingData data, BufferedImage pic, WallTab tab) {
		this.tab = tab;
		this.state = 1;
		this.data = data;
		this.pic = pic;
		this.picOriginal = deepCopy(pic);
		this.meterStickCord = new int[2][2];

		this.addMouseListener(this);
		revalidate();
		repaint();

		// auto run if ready and makes sure the images are the same size
		if (data.getReadyStatus()) {
			try {
				picOriginal = resizeImage(picOriginal, picOriginal.getWidth(),
						data.getWallPixelHeight());
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if (tab.getWallNumber() == 0 && data.getWallFacade(2) != null) {
				try {
					System.out.println("image scaled on tab" + tab.getWallNumber());
					picOriginal = resizeImage(picOriginal, data.getWallFacade(2).getImageW(),
							data.getWallPixelHeight());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (tab.getWallNumber() == 1 && data.getWallFacade(3) != null) {
				try {
					System.out.println("image scaled on tab" + tab.getWallNumber());
					picOriginal = resizeImage(picOriginal, data.getWallFacade(3).getImageW(),
							data.getWallPixelHeight());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (tab.getWallNumber() == 2 && data.getWallFacade(0) != null) {
				try {
					System.out.println("image scaled on tab" + tab.getWallNumber());
					picOriginal = resizeImage(picOriginal, data.getWallFacade(0).getImageW(),
							data.getWallPixelHeight());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else if (tab.getWallNumber() == 2) {
			}
			if (tab.getWallNumber() == 3 && data.getWallFacade(1) != null) {
				try {
					System.out.println("image scaled on tab" + tab.getWallNumber());
					picOriginal = resizeImage(picOriginal, data.getWallFacade(1).getImageW(),
							data.getWallPixelHeight());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			System.out.println("Tab auto ran");
			data.setWallFacade(tab.getWallNumber(), picOriginal);

			this.pic = data.getWallFacade(tab.getWallNumber()).getImageProduct();

			// upDatePicture();

			data.createNBT();

		}
		upDatePicture();

	}

	// stolen method to copy a buffered image
	static BufferedImage deepCopy(BufferedImage bi) {
		ColorModel cm = bi.getColorModel();
		boolean isAlphaPremultiplied = cm.isAlphaPremultiplied();
		WritableRaster raster = bi.copyData(null);
		return new BufferedImage(cm, raster, isAlphaPremultiplied, null);
	}

	// Stolen method to resize a bufferd image
	BufferedImage resizeImage(BufferedImage originalImage, int targetWidth, int targetHeight) throws IOException {
		Image resultingImage = originalImage.getScaledInstance(targetWidth, targetHeight, Image.SCALE_DEFAULT);
		BufferedImage outputImage = new BufferedImage(targetWidth, targetHeight, BufferedImage.TYPE_INT_RGB);
		outputImage.getGraphics().drawImage(resultingImage, 0, 0, null);
		return outputImage;
	}

	public void upDatePicture() {
		if (picture != null) {
			this.remove(picture);
		}
		Image scaled = pic.getScaledInstance(pic.getWidth() / scale, pic.getHeight() / scale, Image.SCALE_SMOOTH);

		picture = new JLabel(new ImageIcon(scaled));

		this.add(picture);
		revalidate();
		repaint();

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		PointerInfo a = MouseInfo.getPointerInfo();
		Point point = new Point(a.getLocation());
		SwingUtilities.convertPointFromScreen(point, picture);
		int x = (int) point.getX();
		int y = (int) point.getY();

		System.out.println(x + " + " + y);

		if (state == 1 && !data.getReadyStatus()) {

			meterStickCord[0][0] = x;
			meterStickCord[0][1] = y;
			// should be spot 0

			pic.getGraphics().drawOval(x * scale, y * scale, 15, 15);
			upDatePicture();

			System.out.println("TEst for mouse click state 1");
			state = 2;

			return;
		}
		if (state == 2 && !data.getReadyStatus()) {

			meterStickCord[1][0] = x;
			meterStickCord[1][1] = y;
			// should be spot 0

			pic.getGraphics().drawOval(x * scale, y * scale, 15, 15);
			upDatePicture();

			data.setWallHeight(meterStickCord, picOriginal);
			data.setWallFacade(tab.getWallNumber(), picOriginal);

			pic = data.getWallFacade(tab.getWallNumber()).getImageProduct();
			upDatePicture();

			System.out.println("TEst for mouse click state 2");
			state = 3;

			// Demo code
			data.createNBT();

			// ******
			return;
		}

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

}
