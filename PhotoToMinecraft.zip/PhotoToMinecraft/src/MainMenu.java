import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;

public class MainMenu extends JPanel {

	private JTabbedPane topMenu;

	/*
	 * @Override protected void paintComponent(Graphics g) { BufferedImage imgBg =
	 * null; try { imgBg = ImageIO.read(new File("manMenuBackGround.png")); } catch
	 * (IOException e) { // TODO Auto-generated catch block e.printStackTrace(); }
	 * super.paintComponent(g); g.drawImage(imgBg, 0, 0, null); }
	 */

	public MainMenu(JTabbedPane topMenu) {
		this.topMenu = topMenu;
		//JButton button1 = new JButton("Convert a single image: \nGood for pixel art and testing purposes.");
		JButton startButton = new JButton("Convert a full building: \nRequires 1 ariel image and 4 pictures of walls.");
		setLayout(new GridLayout(4,1));

		JLabel title = new JLabel("Building ---> MineCraft", SwingConstants.CENTER);
		JLabel footer = new JLabel("A project by Zaniken Gurule", SwingConstants.CENTER);

		startButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent evt) {
				topMenu.add("Aerial", new AerialTab(topMenu));
			}
		});

		float number = 40;
		title.setFont(title.getFont().deriveFont(number));

		add(title);
		add(startButton);
		//add(button1);
		add(footer);
		
	}

}
