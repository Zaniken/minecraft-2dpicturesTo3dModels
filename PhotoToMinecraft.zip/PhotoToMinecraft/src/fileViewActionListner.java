import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.filechooser.FileSystemView;

public class FileViewActionListner implements ActionListener {

	private AerialTab tab;
	private WallTab wallTab;

	public FileViewActionListner(AerialTab tab) {

		this.tab = tab;
	}

	public FileViewActionListner(WallTab wallTab) {
		this.wallTab = wallTab;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JFileChooser jfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
		int x = jfc.showOpenDialog(null);
		if (x == JFileChooser.APPROVE_OPTION) {
			File file = jfc.getSelectedFile();
			try {
				// System.out.println("Bazninga");
				BufferedImage pic = ImageIO.read(file);
				// System.out.println("Bazninga");

				// Image scaled = pic.getScaledInstance(pic.getWidth()/2, pic.getHeight()/2,
				// Image.SCALE_SMOOTH);

				// JLabel picture =new JLabel(new ImageIcon(scaled));
				if (tab != null) {
					tab.addPicture(pic);
				} else {
					wallTab.setOrginImage(pic);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		} else {
			// picture = null;

		}
	}
}