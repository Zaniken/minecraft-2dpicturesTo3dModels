import java.awt.BorderLayout;
import java.awt.image.BufferedImage;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class WallTab extends JPanel {

	private BuildingData data;
	private int wallNumber;
	private JLabel instructions;

	private BufferedImage orginImage;

	public WallTab(BuildingData data, int wallNumber) {
		this.data = data;
		this.wallNumber = wallNumber;
		setLayout(new BorderLayout());
		JButton importButton = new JButton("Import a wall image:");

		importButton.addActionListener(new FileViewActionListner(this));

		instructions = new JLabel("TODO make tooltip here");

		this.add(instructions, BorderLayout.SOUTH);
		this.add(importButton, BorderLayout.NORTH);

	}
	public int getWallNumber() {
		return wallNumber;
	}

	// called form fileViewActionListner
	public void setOrginImage(BufferedImage orginImage) {
		this.orginImage = orginImage;
		this.add(new WallCenterPanel(data, orginImage, this),BorderLayout.CENTER);
		revalidate();
		repaint();

	}
	
	
}
