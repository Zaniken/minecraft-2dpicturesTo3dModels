import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class MinecraftBlocks {

	// Note: minecraft blocks are just 16x16 pngs blown up

	private static Block[] loadedBlocks;

	public static Block[] getLoadedBlocks() {
		return loadedBlocks;
	}
	
	public MinecraftBlocks() {
		File folder = new File("Blocks");
		// System.out.println("test");
		File[] listOfFiles = folder.listFiles();
		loadedBlocks = new Block[listOfFiles.length];
		
		for (int i = 0; i<listOfFiles.length;i++) {
			if (listOfFiles[i].isFile()) {
				System.out.println(listOfFiles[i].getName());
				BufferedImage imageTemp;
				try {
					imageTemp = ImageIO.read(new File(listOfFiles[i].getAbsolutePath()));
					String stringTemp = listOfFiles[i].getName();
					Color colorTemp = averageColor(imageTemp);
					loadedBlocks[i]=new Block(imageTemp, stringTemp, colorTemp);
					System.out.println("Debug: FileName: "+stringTemp+" Average color: "+colorTemp);

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}
	}

	public static Color averageColor(BufferedImage bi) {

		long sumr = 0;
		long sumg = 0;
		long sumb = 0;

		for (int x = 0; x < bi.getWidth(); x++) {
			for (int y = 0; y < bi.getHeight(); y++) {
				Color pixel = new Color(bi.getRGB(x, y));
				sumr += pixel.getRed();
				sumg += pixel.getGreen();
				sumb += pixel.getBlue();
			}
		}
		int num = bi.getHeight() * bi.getWidth();
		return new Color((int) (sumr / num), (int) (sumg / num), (int) (sumb / num));
	}

}
