import java.awt.Image;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.PointerInfo;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;

public class AerialCenterPanel extends JPanel implements MouseListener {
	private AerialTab mainPanel;
	private JLabel picture;
	private BufferedImage pic;
	private final int scale = 2;
	private BuildingData data;
	private int state;
	private JTabbedPane topMenu;

	public AerialCenterPanel(AerialTab mainPanel, BufferedImage pic, BuildingData data, JTabbedPane topMenu) {
		this.mainPanel = mainPanel;
		this.topMenu = topMenu;
		// Image scaled = pic.getScaledInstance(pic.getWidth()/2, pic.getHeight()/2,
		// Image.SCALE_SMOOTH);

		// JLabel picture =new JLabel(new ImageIcon(scaled));
		this.data = data;

		// this.picture = picture;
		// this.add(picture);
		this.pic = pic;
		upDatePicture();
		this.addMouseListener(this);
		revalidate();
		repaint();

	}

	public void upDatePicture() {
		if (picture != null) {
			this.remove(picture);
		}
		Image scaled = pic.getScaledInstance(pic.getWidth() / scale, pic.getHeight() / scale, Image.SCALE_SMOOTH);

		picture = new JLabel(new ImageIcon(scaled));

		this.add(picture);
		revalidate();
		repaint();

	}

	public void setState(int state) {
		this.state = state;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		PointerInfo a = MouseInfo.getPointerInfo();
		Point point = new Point(a.getLocation());
		SwingUtilities.convertPointFromScreen(point, picture);
		int x = (int) point.getX();
		int y = (int) point.getY();

		System.out.println(x + " + " + y);

		// first cord sent
		if (state == 1) {
			int[] cord = new int[2];
			cord[0] = e.getX();
			cord[1] = e.getY();
			// should be spot 0

			data.addCord(cord);

			pic.getGraphics().drawOval(x * scale, y * scale, 15, 15);
			upDatePicture();

			System.out.println("TEst for mouse click state 1");
			state = 2;

			return;
		}
		// second cord sent and from that the meter size can be found
		if (state == 2) {
			System.out.println("TEst for mouse click state 2");
			int[] cord = new int[2];
			cord[0] = e.getX();
			cord[1] = e.getY();
			// should be spot 1
			data.addCord(cord);
			data.setMeterPixels();
			mainPanel.upDateEastStage();

			pic.getGraphics().drawOval(x * scale, y * scale, 15, 15);
			upDatePicture();

			repaint();
			state = 3;
			return;
		}
		// STATE 3 begins our process of adding cords of our buildings corner
		// Corner 1
		if (state > 2 && state <= 6) {
			System.out.println("Test for mouse click state: " + state);
			int[] cord = new int[2];
			cord[0] = e.getX();
			cord[1] = e.getY();
			// should be spot 1
			data.addCord(cord);

			// mainPanel.upDateEastStage();

			pic.getGraphics().fillOval(x * scale, y * scale, 15, 15);

			if (state == 6) {

				data.setWallSizes();

				System.out.println("State 6 ran! wall sizes: 1: " + data.getWallSize(0));
				System.out.println("State 6 ran! wall sizes: 2: " + data.getWallSize(1));
				System.out.println("State 6 ran! wall sizes: 3: " + data.getWallSize(2));
				System.out.println("State 6 ran! wall size in Meters 1: " + data.getWallSizeInMeters(0));
				System.out.println("State 6 ran! wall size in meters: 2 " + data.getWallSizeInMeters(1));

				topMenu.add("Wall 1", new WallTab(data, 0));
				topMenu.add("Wall 2", new WallTab(data, 1));
				topMenu.add("Wall 3", new WallTab(data, 2));
				topMenu.add("Wall 4", new WallTab(data, 3));
			}
			upDatePicture();
			repaint();
			state++;
			return;
		}

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

}
